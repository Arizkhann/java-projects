package com.java.jsf;

public enum Gender {

	
	
	male,female
}
